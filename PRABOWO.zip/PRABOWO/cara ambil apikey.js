


CARA AMBIL APIKEY JIKA APIKEY HABIS

SILAHKAN REGISTRASI DULU KE WEBSITE
https://free-restapi.biz.id/users/register

SETELAH REGISTER LALU LOGIN MENGGUNAKAN AKUN YANG TELAH DI REGISTRASI 

https://free-restapi.biz.id/users/login

SETELAH LOGIN lalu salin link di bawah ini 
https://free-restapi.biz.id/profile

salin apikey nya lalu ganti apiKey dengan yang baru

cari file setting.js di sc bot aqua
lalu cari global.sakey = "ganti apikey yang baru lu salin di website"


INGIN BUY APIKEY ?
https://free-restapi.biz.id/pricing
atau bisa juga lewat WhatsApp 


