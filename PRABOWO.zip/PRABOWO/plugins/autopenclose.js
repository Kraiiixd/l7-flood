const fs = require('fs')
const path = require('path')
const cron = require('node-cron')

const DATABASE_PATH = path.join(process.cwd(), 'database', 'autocloseopen.json')

function ensureDatabase() {
    if (!fs.existsSync(path.join(process.cwd(), 'database'))) {
        fs.mkdirSync(path.join(process.cwd(), 'database'), { recursive: true })
    }
    if (!fs.existsSync(DATABASE_PATH)) {
        fs.writeFileSync(DATABASE_PATH, JSON.stringify({ groups: {} }, null, 2))
    }
}

function readDatabase() {
    ensureDatabase()
    try {
        const data = fs.readFileSync(DATABASE_PATH, 'utf8')
        return JSON.parse(data)
    } catch (e) {
        return { groups: {} }
    }
}

function writeDatabase(data) {
    ensureDatabase()
    fs.writeFileSync(DATABASE_PATH, JSON.stringify(data, null, 2))
}

function getGroupSetting(jid) {
    const db = readDatabase()
    if (!db.groups[jid]) {
        db.groups[jid] = {
            enabled: false,
            openTime: '05:00',
            closeTime: '12:00'
        }
        writeDatabase(db)
    }
    return db.groups[jid]
}

function updateGroupSetting(jid, settings) {
    const db = readDatabase()
    if (!db.groups[jid]) {
        db.groups[jid] = {
            enabled: false,
            openTime: '05:00',
            closeTime: '12:00'
        }
    }
    Object.assign(db.groups[jid], settings)
    writeDatabase(db)
}

if (!global.cronJobs) {
    global.cronJobs = new Map()
}

const delay = ms => new Promise(r => setTimeout(r, ms))

function getNow() {
    return new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Jakarta' }))
}

function getTimeString(date) {
    return date.toTimeString().slice(0, 5)
}

function parseTime(timeStr) {
    const [h, m] = timeStr.split(':').map(Number)
    return { hours: h, minutes: m }
}

function isTimeBetween(now, startTime, endTime) {
    const current = now.getHours() * 60 + now.getMinutes()
    const start = parseTime(startTime)
    const end = parseTime(endTime)
    const startTotal = start.hours * 60 + start.minutes
    const endTotal = end.hours * 60 + end.minutes
    
    if (startTotal <= endTotal) {
        return current >= startTotal && current < endTotal
    } else {
        return current >= startTotal || current < endTotal
    }
}

async function setGroupSetting(satanic, jid, setting, retries = 3) {
    for (let i = 0; i < retries; i++) {
        try {
            await satanic.groupSettingUpdate(jid, setting)
            return true
        } catch (e) {
            if (i === retries - 1) return false
            await delay(1000 * (i + 1))
        }
    }
    return false
}

function startCron(satanic, jid) {
    if (global.cronJobs.has(jid)) {
        global.cronJobs.get(jid).forEach(job => job.stop())
        global.cronJobs.delete(jid)
    }

    const setting = getGroupSetting(jid)
    if (!setting.enabled) return

    const jobs = []
    const [openHour, openMin] = setting.openTime.split(':').map(Number)
    const [closeHour, closeMin] = setting.closeTime.split(':').map(Number)

    const openCron = cron.schedule(`${openMin} ${openHour} * * *`, async () => {
        try {
            await setGroupSetting(satanic, jid, 'not_announcement')
        } catch (e) {}
    }, {
        timezone: "Asia/Jakarta"
    })
    jobs.push(openCron)

    const closeCron = cron.schedule(`${closeMin} ${closeHour} * * *`, async () => {
        try {
            await setGroupSetting(satanic, jid, 'announcement')
        } catch (e) {}
    }, {
        timezone: "Asia/Jakarta"
    })
    jobs.push(closeCron)

    global.cronJobs.set(jid, jobs)
}

function stopCron(jid) {
    if (global.cronJobs.has(jid)) {
        global.cronJobs.get(jid).forEach(job => job.stop())
        global.cronJobs.delete(jid)
    }
}

function restartCron(satanic, jid) {
    stopCron(jid)
    const setting = getGroupSetting(jid)
    if (setting.enabled) {
        startCron(satanic, jid)
    }
}

let handler = async (m, { satanic, text, command, prefix, isCreator }) => {
    if (!m.isGroup) return m.reply('Fitur ini khusus grup.')

    const setting = getGroupSetting(m.chat)

    if (command === 'autoclose') {
        if (!text) {
            const buttons = [
                { buttonId: `${prefix}autoclose on`, buttonText: { displayText: 'ON' }, type: 1 },
                { buttonId: `${prefix}autoclose off`, buttonText: { displayText: 'OFF' }, type: 1 },
                { buttonId: `${prefix}autoclose status`, buttonText: { displayText: 'STATUS' }, type: 1 },
                { buttonId: `${prefix}autoclose reset`, buttonText: { displayText: 'RESET' }, type: 1 },
                { buttonId: `${prefix}setopen`, buttonText: { displayText: 'SET OPEN' }, type: 1 },
                { buttonId: `${prefix}setclose`, buttonText: { displayText: 'SET CLOSE' }, type: 1 }
            ]

            const buttonMessage = {
                text: `AUTOCLOSEOPEN (CRON)\n\nBuka: ${setting.openTime}\nTutup: ${setting.closeTime}\nStatus: ${setting.enabled ? 'Aktif' : 'Mati'}\n\nPilih menu di bawah:`,
                footer: 'AQUA MD',
                buttons: buttons,
                headerType: 1
            }

            await satanic.sendMessage(m.chat, buttonMessage)
            return
        }

        const type = text.toLowerCase().trim()

        if (type === 'on') {
            updateGroupSetting(m.chat, { enabled: true })
            
            const settingBaru = getGroupSetting(m.chat)
            const now = getNow()
            const isOpen = isTimeBetween(now, settingBaru.openTime, settingBaru.closeTime)
            
            if (isOpen) {
                await setGroupSetting(satanic, m.chat, 'not_announcement')
            } else {
                await setGroupSetting(satanic, m.chat, 'announcement')
            }
            
            startCron(satanic, m.chat)
            return m.reply(`AutoCloseOpen Aktif (Cron)\nBuka: ${settingBaru.openTime}\nTutup: ${settingBaru.closeTime}\nAkan buka/tutup otomatis setiap hari`)
        }

        if (type === 'off') {
            updateGroupSetting(m.chat, { enabled: false })
            stopCron(m.chat)
            return m.reply('AutoCloseOpen Dimatikan')
        }

        if (type === 'status') {
            const enabled = setting.enabled ? 'Aktif' : 'Mati'
            const now = getNow()
            const isOpen = isTimeBetween(now, setting.openTime, setting.closeTime)
            const hasCron = global.cronJobs.has(m.chat)
            return m.reply(`STATUS AUTOCLOSEOPEN (CRON)\n\nStatus: ${enabled}\nJam Buka: ${setting.openTime}\nJam Tutup: ${setting.closeTime}\nSaat Ini: ${isOpen ? 'Jam Buka' : 'Jam Tutup'}\nCron: ${hasCron ? 'Berjalan' : 'Berhenti'}\nWaktu Sekarang: ${getTimeString(now)}`)
        }

        if (type === 'reset') {
            updateGroupSetting(m.chat, {
                enabled: false,
                openTime: '05:00',
                closeTime: '12:00'
            })
            stopCron(m.chat)
            return m.reply(`AutoClose Direset ke Default\n\nBuka: 05:00\nTutup: 12:00`)
        }
    }

    if (command === 'setopen') {
        if (!text) return m.reply(`Format: ${prefix}setopen HH:MM\nContoh: ${prefix}setopen 05:00`)
        
        const timeRegex = /^([0-1][0-9]|2[0-3]):[0-5][0-9]$/
        if (!timeRegex.test(text)) {
            return m.reply('Format waktu salah. Gunakan HH:MM (contoh: 05:00)')
        }

        updateGroupSetting(m.chat, { openTime: text })
        
        if (setting.enabled) {
            restartCron(satanic, m.chat)
        }
        
        return m.reply(`Jam Buka Diubah\n${text} WIB`)
    }

    if (command === 'setclose') {
        if (!text) return m.reply(`Format: ${prefix}setclose HH:MM\nContoh: ${prefix}setclose 12:00`)
        
        const timeRegex = /^([0-1][0-9]|2[0-3]):[0-5][0-9]$/
        if (!timeRegex.test(text)) {
            return m.reply('Format waktu salah. Gunakan HH:MM (contoh: 12:00)')
        }

        updateGroupSetting(m.chat, { closeTime: text })
        
        if (setting.enabled) {
            restartCron(satanic, m.chat)
        }
        
        return m.reply(`Jam Tutup Diubah\n${text} WIB`)
    }
}

handler.all = async function () {
    const satanic = this
    ensureDatabase()
    const db = readDatabase()
    
    for (const jid of Object.keys(db.groups)) {
        const setting = db.groups[jid]
        if (setting?.enabled && !global.cronJobs.has(jid)) {
            const now = getNow()
            const isOpen = isTimeBetween(now, setting.openTime, setting.closeTime)
            if (isOpen) {
                await setGroupSetting(satanic, jid, 'not_announcement')
            } else {
                await setGroupSetting(satanic, jid, 'announcement')
            }
            startCron(satanic, jid)
            await delay(500)
        }
    }
}

handler.help = ['autoclose', 'setopen', 'setclose']
handler.tags = ['group']
handler.command = /^(autoclose|setopen|setclose)$/i
handler.group = true
handler.admin = true

module.exports = handler