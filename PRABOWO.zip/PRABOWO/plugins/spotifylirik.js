const axios = require('axios');

async function getLyrics(queryOrTrack, artist) {
  let trackName = queryOrTrack;
  let artistName = artist || '';

  if (queryOrTrack.includes('spotify.com/track/')) {
    const match = queryOrTrack.match(/track\/([a-zA-Z0-9]+)/);
    if (match) {
      try {
        const oembed = await axios.get(
          `https://open.spotify.com/oembed?url=https://open.spotify.com/track/${match[1]}`,
          { timeout: 5000 }
        );
        trackName = oembed.data?.title?.replace(/\(feat\..*?\)/i, '').trim() || trackName;
        const resEmbed = await axios.get(`https://open.spotify.com/embed/track/${match[1]}`, { timeout: 5000 });
        const matchArtist = resEmbed.data.match(/"artists":\[\{"name":"([^"]+)"/);
        if (matchArtist) {
          artistName = matchArtist[1];
        }
      } catch (_) {}
    }
  }

  try {
    const res = await axios.get('https://lrclib.net/api/get', {
      params: {
        track_name: trackName,
        artist_name: artistName,
      },
      timeout: 10000,
    });

    if (res.data && (res.data.plainLyrics || res.data.syncedLyrics)) {
      return {
        status: true,
        trackName: res.data.trackName || trackName,
        artistName: res.data.artistName || artistName,
        albumName: res.data.albumName,
        duration: res.data.duration,
        plainLyrics: res.data.plainLyrics,
        syncedLyrics: res.data.syncedLyrics,
      };
    }
  } catch (_) {}

  try {
    const searchRes = await axios.get('https://lrclib.net/api/search', {
      params: {
        q: `${trackName} ${artistName}`.trim(),
      },
      timeout: 10000,
    });

    if (Array.isArray(searchRes.data) && searchRes.data.length > 0) {
      const best = searchRes.data[0];
      return {
        status: true,
        trackName: best.trackName,
        artistName: best.artistName,
        albumName: best.albumName,
        duration: best.duration,
        plainLyrics: best.plainLyrics,
        syncedLyrics: best.syncedLyrics,
      };
    }
  } catch (err) {
    return {
      status: false,
      message: err.message || 'Gagal mengambil lirik',
    };
  }

  return {
    status: false,
    message: 'Lirik lagu tidak ditemukan',
  };
}

let handler = async (m, { satanic, text, prefix, command }) => {
  if (!text) return m.reply(`Contoh: ${prefix + command} https://open.spotify.com/track/xxx`);

  await satanic.sendMessage(m.chat, {
    react: { text: '⏳', key: m.key },
  });

  try {
    const result = await getLyrics(text);

    if (!result.status) {
      await satanic.sendMessage(m.chat, {
        react: { text: '❌', key: m.key },
      });
      return m.reply(result.message || 'Lirik tidak ditemukan.');
    }

    await satanic.sendMessage(m.chat, {
      react: { text: '✅', key: m.key },
    });

    let caption = `🎵 ${result.trackName} - ${result.artistName}`;
    if (result.albumName) caption += `\n💽 Album: ${result.albumName}`;
    if (result.duration) {
      const menit = Math.floor(result.duration / 60);
      const detik = String(Math.floor(result.duration % 60)).padStart(2, '0');
      caption += `\n⏱ Durasi: ${menit}:${detik}`;
    }
    caption += '\n\n--- LIRIK ---\n';
    caption += result.syncedLyrics || result.plainLyrics || 'Tidak ada lirik.';

    if (caption.length > 4096) {
      caption = caption.slice(0, 4096) + '\n\n... (terpotong)';
    }

    satanic.sendMessage(m.chat, { text: caption }, { quoted: m });

  } catch (err) {
    await satanic.sendMessage(m.chat, {
      react: { text: '⚠️', key: m.key },
    });
    m.reply('Error: ' + err.message);
  }
}

handler.help = ['spotifylirik <link spotify>'];
handler.tags = ['music'];
handler.command = /^(spotifylirik|spotifylyrics)$/i;
handler.limit = false;

module.exports = handler;