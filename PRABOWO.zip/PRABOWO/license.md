PRABOWO MD — RELEASE LICENSE
Copyright (c) 2026 FallZx Infinity

Creator      : FallZx Infinity
Contact      : fallzxcoderid@gmail.com
Original Base: Satanic
Panel        : fallxdstore.zone.id


BASE PEMILIK : 
WHATSAPP: 6285196895485 ( SATAN)
TELEGRAM: t.me/Fourttwentyonezero
LIVECHAT: https://free-restapi.biz.id/livechat
FORUM: https://free-restapi.biz.id/forum

==================================================
                    LICENSE
==================================================

Prabowo MD adalah perangkat lunak yang dikembangkan
dan dirilis oleh FallZx Infinity.

Dengan menggunakan, menyalin, memodifikasi, atau
mendistribusikan Prabowo MD, Anda dianggap telah
membaca dan menyetujui ketentuan lisensi ini.

1. HAK KEPEMILIKAN
--------------------------------------------------

Seluruh source code, struktur, fitur, konfigurasi,
branding, nama Prabowo MD, serta komponen tambahan
yang dikembangkan oleh FallZx Infinity merupakan
hak milik pembuatnya, kecuali komponen yang secara
jelas berasal dari pihak lain.

Original Base:
Satanic

Penggunaan base pihak ketiga tetap tunduk pada
lisensi dan ketentuan yang berlaku dari pemilik
base tersebut.

2. IZIN PENGGUNAAN
--------------------------------------------------

Pengguna diperbolehkan untuk:

- Menggunakan Prabowo MD untuk kebutuhan pribadi.
- Menjalankan bot pada server atau perangkat sendiri.
- Melakukan konfigurasi sesuai kebutuhan penggunaan.
- Melakukan modifikasi untuk penggunaan pribadi.

3. LARANGAN
--------------------------------------------------

Tanpa izin tertulis dari FallZx Infinity, dilarang:

- Menjual ulang source code Prabowo MD.
- Mendistribusikan ulang source code sebagai produk
  milik sendiri.
- Mengklaim Prabowo MD sebagai karya sendiri.
- Menghapus atau mengganti informasi copyright,
  creator, atau attribution yang terdapat pada source.
- Menggunakan nama FallZx Infinity untuk menjual
  versi modifikasi tanpa izin.
- Mengunggah ulang
